/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClockinAndOutRegSystem;

/**
 *
 * @author richa
 */
import java.io.*;
import java.time.format.DateTimeFormatter;
import java.time.LocalTime;
import java.util.Arrays;
import java.util.Scanner;

import static java.lang.System.*;

public class Attend1<T> {

    static Object DStructures;
    //private Person student;
    private static String[] cTimes;//cohort times
    private static LocalTime[] clockTimes;//start and end times
    private static int [][] signIn;  //attendance sheet
    private static int numStudents;    //num of students enroll in course
    private static Person[] students;
    private static int Tcohorts;   //num of cohorts
    private static final int  Tclasses= 10;
    private static String nowTime;    //this holds the current for each student
    
    public Attend1(int numCohorts, int numStudents){
        //this.student=null;
        this.cTimes= new String[numCohorts];
        this.clockTimes= new LocalTime[numCohorts*2];
        this.signIn= new int[numStudents][Tclasses];
        this.numStudents= numStudents;
        this.students= new Person[numStudents];
        this.Tcohorts= numCohorts;
        
    }
    
    public static String[] getCTimes(){
        return cTimes;
    }
    
    public static LocalTime[] getClockTimes(){
        return clockTimes;
    }
    
    public static int[][] getsignIn(){
        return signIn;
    }
    
    public static int getNumStudents(){
        return numStudents;
    }
    
    public static Person[] getStudents(){
        return students;
    }
    
    public static int getTcohorts(){
        return Tcohorts;
    }
    
    public static String getNowTime(){
        return nowTime;
    }
    
    public static void setNowTime(LocalTime time){
        //time= LocalTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        nowTime=time.format(formatter);
    }
    
    public static void addCTimes(String[] cTime){
        for(int i = 0; i<cTime.length;i++){
            cTimes[i]= cTime[i];
        }
    }
    
    public static void addClockTimes(String[] clockTime){
        //String time = "08:00:00";
        //LocalTime lTime= LocalTime.parse(time);
        //System.out.println(lTime);
        //DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        for(int i = 0; i<clockTime.length;i++){
            
            clockTimes[i]= LocalTime.parse(clockTime[i]);
            if(i%2==0)
                System.out.println("The end time of that cohort is: "+clockTimes[i]);
            else
                System.out.println("The start time of the cohort "+ i+" is: "+clockTimes[i]);
        }
        
    }
    
    public static boolean addStudent(Person student){
         //adds person objects to students array. Checks if there are any empty slots in the student array. If there are, it replaces null with the person object and returns true. Else, returns false.         for(int i=0;i<students.length;i++){
         for(int i = 0; i< getStudents().length;i++){
            if(students[i]==null){
                students[i]=student;
                return true;
            }
         }
         return false;
     }
    
    // checks if enrollment sheet is empty
    public static boolean enrolSheetCheck(String nfile){
        File oldFile= new File(nfile);
        if(oldFile.exists() && oldFile.length()==0){
            System.out.println(oldFile.length()+ "File is empty!");
            return true;
        }
        System.out.println(oldFile.length());
        return false;
    }
    
    
    
    public static void main(String args[]){
        Stack<Integer>classIndex= new Stack<>();
        LocalTime time= LocalTime.now();
        Scanner scan = new Scanner(System.in);
        
        Attend1<String>DStructures= new Attend1<>(2, 2);
        String [] cTime= {"08:00:00","09:45:00"};
        String [] clockTime={"08:00:00","09:30:00","09:45:00","11:15:00"};
        
        
        
        DStructures.addCTimes(cTime);
        DStructures.addClockTimes(clockTime);
        
        System.out.println(Arrays.toString(DStructures.getCTimes()));    
        Person.Gender [] genders= new Person.Gender[2];
        genders[0]= Person.Gender.MALE;
        genders[1]= Person.Gender.FEMALE;
        
        
        try{
            String fileName= "enrollmentSheet.txt";
            String fileName1= "attendanceSheet.txt";

            FileWriter filew= new FileWriter(fileName,true);
            FileWriter filew1= new FileWriter(fileName1,true);
            
            PrintWriter printW= new PrintWriter(filew);
            PrintWriter printW1= new PrintWriter(filew1);
            printW.print("Name/t");
            printW.print("Age/t");
            printW.print("Gender/t");
            printW.println("ID");
            printW1.print("ID");
            printW1.println("Attendance slot");
            if(DStructures.enrolSheetCheck(fileName)){
                System.out.println("Hey ");
                for(int i = 0; i< DStructures.getNumStudents();i++){
                    System.out.println("Enter student's name");
                    String name= scan.next();

                    System.out.println("Enter student's age");
                    int age= scan.nextInt();

                    System.out.println("Enter student's gender(MALE=0, FEMALE= 1)");
                    Person.Gender gender= genders[scan.nextInt()];

                    System.out.println("Enter student's id number");
                    long id = scan.nextLong();

                    Person student = new Person(name, age, gender, id);
                    printW.print(name);
                    printW.print(age);
                    printW.print(gender);
                    printW.println(id);
                    printW1.println(id);
                    System.out.println(DStructures.addStudent(student));

                }
                printW.close();
                printW1.close();
            }
            else{
                System.out.println("Do you want append new students to the enrollment sheet? Type y(Yes) or n(No).");
                String ans=scan.nextLine();
                if(ans.equals("y")){
                    
                    BufferedWriter br = new BufferedWriter(filew);
                    BufferedWriter br1 = new BufferedWriter(filew1);
                    PrintWriter pr= new PrintWriter(br);
                    PrintWriter pr1= new PrintWriter(br1);

                    System.out.println("How many students do you want to add to enrollment sheet?");
                    int num=scan.nextInt();
                    for(int j =0; j<num;j++){
                        System.out.println("Enter student's name");
                        String name= scan.next();

                        System.out.println("Enter student's age");
                        int age= scan.nextInt();

                        System.out.println("Enter student's gender(MALE=0, FEMALE= 1)");
                        Person.Gender gender= genders[scan.nextInt()];

                        System.out.println("Enter student's id number");
                        long id = scan.nextLong();

                        Person student = new Person(name, age, gender, id);
                        pr.print(name);
                        pr.print(age);
                        pr.print((Person.Gender)gender);
                        pr.print((int) id);
                        pr1.print((int) id);
                        System.out.println(DStructures.addStudent(student));

                    }
                    br.close();
                    br1.close();
                }
                else{
                    return;
                }
            }
        }catch(IOException e){
            out.println("ERROR");
        }
        System.out.println(Arrays.toString(DStructures.getStudents()));    
        
       
    }
}
