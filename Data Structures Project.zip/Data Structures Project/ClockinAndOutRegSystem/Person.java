/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClockinAndOutRegSystem;

/**
 *
 * @author richa
 */
public class Person {
    
     //declaring instance variables
    public static enum Gender{MALE, FEMALE};
    private String name;
    private Gender gender;
    private int age;
    private long indexNum;
    
    //default constructor that sets the name instance variable to "No name yet" and the age variable to zero
    public Person(){
        this.name= "No name yet";
        this.age = 0;
        this.gender= Gender.FEMALE;
        this.indexNum=0;
    }
    
    //creates the constructor that sets the local variables name, age and gender, index number to their instance variables.
    public Person(String name, int age, Gender gender, long indexNum){
        this.name= name;
        this.age = age;
        this.gender= gender;
        this.indexNum= indexNum;
    }
    
    //accesor methods for each instance variable
    public String getName(){return name;}
    public Gender getGender(){return gender;}
    public int getAge(){return age;}
    public long getIndex(){return indexNum;}
    
    public void setName(String name){
        //sets the name to the person object
        this.name= name;
       
    }
    public void setName(String first, String last){
        //sets the first and last name of the person object and concatenates them
        this.name = first + last;
    }
    
    public int incrementAge(){
        //increments the age of the the person object
    this.age++;
    return this.age;
    }
    
    public boolean equals(Person resident1){
//        determines the equality between 2 person objects
    if(getName()==resident1.getName() && getAge()==resident1.getAge() && getGender()==resident1.getGender() ){
             
             return true;

         }
    else return false;
    }
}
