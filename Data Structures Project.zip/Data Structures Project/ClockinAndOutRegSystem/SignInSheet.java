/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClockinAndOutRegSystem;

import static ClockinAndOutRegSystem.Attend1.DStructures;
import java.time.LocalTime;
import java.util.Scanner;
import java.io.*;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
/**
 *
 * @author richa
 */
public class SignInSheet<T> {
    
    public static void main(String args[]){
        Stack<Long>classIndex= new Stack<>();
        
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Enter your ID:");
        long id= scan.nextLong();
        
        System.out.println("Enter your cohort number (A=0,B=2):");
        int cNum= scan.nextInt();
        
        if(cNum ==0){
            LocalTime time= LocalTime.now();
            DStructures.setNowTime(time);
            if(time >= Attend1.DStructures.clockTimes[0]){
                classIndex.push(id);
            }
            else{
                
                
            }
        }
    }
}
